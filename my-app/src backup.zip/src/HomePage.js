import React, { useEffect, useState } from "react";
import { useOkto } from "okto-sdk-react";
import { useNavigate } from "react-router-dom";
import Tesseract from 'tesseract.js';

function HomePage() {
  console.log("HomePage component rendered");
  const navigate = useNavigate();
  const [userDetails, setUserDetails] = useState(null);
  const [portfolioData, setPortfolioData] = useState(null);
  const [wallets, setWallets] = useState(null);
  const [transferResponse, setTransferResponse] = useState(null);
  const [orderResponse, setOrderResponse] = useState(null);
  const [error, setError] = useState(null);
  const [activeSection, setActiveSection] = useState(null);
  const { getUserDetails, getPortfolio, createWallet, transferTokens, orderHistory } = useOkto();
  const [transferData, setTransferData] = useState({
    network_name: "",
    token_address: "",
    quantity: "",
    recipient_address: "",
  });
  const [userdb, setuserdb] = useState({
    email: "",
    address: "",
    quantity: "",
    coin: ""
  });
  const [orderData, setOrderData] = useState({
    order_id: "",
  });
  const [image1, setImage1] = useState(null);
  const [image2, setImage2] = useState(null);
  const [billAmount, setBillAmount] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleImage1Change = (event) => {
    setImage1(event.target.files[0]);
  };

  const handleImage2Change = (event) => {
    setImage2(event.target.files[0]);
  };

  // Combining add_user and get_user logic in one useEffect
  useEffect(() => {
    const fetchData = async () => {
      try {

        // Creating wallet and fetching portfolio
        const walletsData = await createWallet();
        const portfolio = await getPortfolio();
        console.log(portfolio)
        console.log(walletsData)
        console.log("Wallets created:", walletsData.wallets[1].address);
        console.log("Portfolio fetched:", portfolio.tokens[0].quantity);
        const details = await getUserDetails();
        // Storing user details in the database
        const addUserResponse = await fetch('http://localhost:3001/userstorage/user', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            emailid: details.email,
            address: walletsData.wallets[1].address,
            quantity: portfolio.tokens[0].quantity,
          }),
        });
        const addUserData = await addUserResponse.json();
        console.log('User added:', addUserData);

        // Fetching user details
        
        console.log("User details fetched:", details.email);

        // Fetch user data from the database
        const userResponse = await fetch('http://localhost:3001/userstorage/getuser', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ email: details.email }),
        });
        const userData = await userResponse.json();
        console.log('User data fetched:', userData);
        setuserdb(userData);

        

      } catch (error) {
        console.error('Error connecting or fetching user:', error);
      }
    };

    fetchData();
  }, [getUserDetails, getPortfolio, createWallet]);

  // Watch userdb for changes and log it
  useEffect(() => {
    if (userdb.email) {
      console.log('Userdb updated:', userdb);
    }
  }, [userdb]);

  const extractBillAmount = async () => {
    if (!image1) {
      setError("Please upload an image first.");
      return;
    }

    setLoading(true);
    try {
      // Tesseract.js OCR processing
      const { data: { text } } = await Tesseract.recognize(image1, 'eng', {
        logger: (m) => console.log(m),
      });
      const amountMatch = text.match(/(\d+\.\d{2})/);
      console.log("Amount Match:", amountMatch[0]);
      setBillAmount(amountMatch ? amountMatch[1] : "Unable to detect amount");
      console.log(billAmount)
      if(amountMatch[0]>0){
        console.log(billAmount)
        try{
          const details = await getUserDetails();
          console.log(details.email)
          const portfolio = await getPortfolio();
          console.log(portfolio.tokens[0].quantity)
          const response = await fetch('http://localhost:3001/userstorage/updatecoins', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({ email: details.email , coin : parseInt(amountMatch[0]), quantity: portfolio.tokens[0].quantity }),
          });
          const data = await response.json();
          console.log('Data:', data);
          window.location.reload();
        }catch(err){
          console.log(err);
        }
      }
    } catch (error) {
      console.error('Error extracting bill amount:', error);
      setError("Failed to extract bill amount.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h1>Welcome to the HomePage</h1>

      {/* Render your content here */}
      <div>
        <input type="file" onChange={handleImage1Change} />
        <input type="file" onChange={handleImage2Change} />
        <button onClick={extractBillAmount}>Extract Bill Amount</button>
      </div>

      {loading && <p>Loading...</p>}
      {error && <p>{error}</p>}
      {billAmount && <p>Extracted Bill Amount: {billAmount}</p>}

      {/* Display userdb info */}
      {userdb.email && (
        <div>
          <p>User Email: {userdb.email}</p>
          <p>User Address: {userdb.address}</p>
          <p>User Quantity: {userdb.coin}</p>
        </div>
      )}
    </div>
  );
}

export default HomePage;
